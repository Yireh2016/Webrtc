/*global define */
define(['backbone'], function (Backbone) {
    return Backbone.noConflict();
});
