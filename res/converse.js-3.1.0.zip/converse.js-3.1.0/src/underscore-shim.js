/*global define */
define(['lodash'], function (_) {
    return _.noConflict();
});
