({
    baseUrl: "../",
    name: "almond",
    mainConfigFile: 'config.js',
    wrap: {
        startFile: "start.frag",
        endFile: "inverse-end.frag"
    }
})
