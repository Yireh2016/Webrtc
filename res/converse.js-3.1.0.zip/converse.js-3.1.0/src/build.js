({
    baseUrl: "../",
    name: "almond",
    mainConfigFile: 'config.js',
    wrap: {
        startFile: "start.frag",
        endFile: "end.frag"
    }
})
